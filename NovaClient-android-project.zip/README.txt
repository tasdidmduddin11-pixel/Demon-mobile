Build the APK online (no PC needed)
1. Make a free GitHub account, create a new repository, and upload ALL files from this zip (keep the folders, including .github).
2. Open the repository's Actions tab, pick "Build APK" and wait about 3-5 minutes.
3. Open the finished run, download "NovaClient-apk", unzip it and install app-debug.apk on your phone (allow "install unknown apps" when asked).
