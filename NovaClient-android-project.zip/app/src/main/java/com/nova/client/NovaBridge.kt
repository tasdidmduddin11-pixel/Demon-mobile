package com.nova.client

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface
import org.json.JSONObject

/** Every method takes one String (the web UI always sends one) and returns a JSON string with "ok". */
class NovaBridge(private val ctx: Context, private val pickFile: () -> Unit) {
    companion object { const val MC = "com.mojang.minecraftpe" }
    private fun json(vararg p: Pair<String, Any?>) = JSONObject(p.toMap()).toString()
    private fun launchIntent(): Intent? = ctx.packageManager.getLaunchIntentForPackage(MC)

    @JavascriptInterface fun getMinecraftLaunchStatus(arg: String) = json("ok" to true, "available" to (launchIntent() != null))

    @JavascriptInterface fun launchMinecraft(arg: String): String {
        val i = launchIntent() ?: return json("ok" to false, "reason" to "not_installed")
        return try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); json("ok" to true, "launched" to true)
        } catch (e: Exception) { json("ok" to false, "reason" to "launch_failed") }
    }

    /** Ignores web-supplied paths. The user picks the file through the system picker, then it is shared via FileProvider. */
    @JavascriptInterface fun importPackIntoMinecraft(arg: String): String {
        if (launchIntent() == null) return json("ok" to false, "reason" to "not_installed")
        android.os.Handler(ctx.mainLooper).post { pickFile() }
        return json("ok" to true, "verified" to false)
    }

    @JavascriptInterface fun getInstalledMinecraftVersion(arg: String): String = try {
        json("ok" to true, "version" to ctx.packageManager.getPackageInfo(MC, 0).versionName)
    } catch (e: Exception) { json("ok" to false, "reason" to "not_installed") }

    @JavascriptInterface fun getDeviceInformation(arg: String): String {
        val m = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m)
        fun gb(b: Long) = String.format("%.1f GB", b / 1073741824.0)
        return json("ok" to true, "model" to "${Build.MANUFACTURER} ${Build.MODEL}", "androidVersion" to Build.VERSION.RELEASE,
            "totalMemory" to gb(m.totalMem), "availableMemory" to gb(m.availMem))
    }

    @JavascriptInterface fun getAndroidStorageCapabilities(arg: String) = json("ok" to true, "saf" to true, "shareToMinecraft" to (launchIntent() != null))
}
