package com.nova.client

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null

    // File input inside the web UI (library import)
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooserCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooserCb = null
    }

    // "Import into Minecraft": user picks the pack via Storage Access Framework
    private val handoffPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handOffToMinecraft(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                // Anything external opens in the browser, never inside the bridge-enabled WebView
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: ActivityNotFoundException) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooserCb?.onReceiveValue(null); chooserCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (_: Exception) { chooserCb = null; false }
            }
        }
        web.addJavascriptInterface(NovaBridge(this) { handoffPicker.launch(arrayOf("*/*")) }, "NovaNative")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun handOffToMinecraft(uri: Uri) {
        try {
            val name = (uri.lastPathSegment ?: "pack.mcpack").substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"), "_")
            if (!Regex("(?i).*\\.(mcpack|mcaddon|mcworld)$").matches(name)) {
                Toast.makeText(this, "Choose a .mcpack, .mcaddon or .mcworld file.", Toast.LENGTH_LONG).show(); return
            }
            val dir = File(cacheDir, "share").apply { mkdirs() }
            val out = File(dir, name)
            contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
            val shared = FileProvider.getUriForFile(this, "$packageName.fileprovider", out)
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(shared, "application/octet-stream")
                .setPackage(NovaBridge.MC).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Minecraft couldn’t open this file.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn’t read that file.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
